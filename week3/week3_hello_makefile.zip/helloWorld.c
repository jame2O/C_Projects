#include <stdio.h>
#include "functionFile.h"

int main (int argc, char **argv) {
    int i = 0;

    printf ("Hello World\n");
    printf ("The value of i is %d\n", i);

    important_function(42);

    return 0;
}
