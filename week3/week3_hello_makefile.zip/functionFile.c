#include "functionFile.h"
#include <stdio.h>

void important_function(const int parameter)
{
    printf("Important: I think: %d\n", parameter);
}
