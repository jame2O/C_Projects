#ifndef __FUNCTION_FILE_H
#define __FUNCTION_FILE_H

void important_function(const int parameter);

#endif



